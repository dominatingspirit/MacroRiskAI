import os
import time
import glob
import requests
import pandas as pd

# ----------------------------
# CONFIG
# ----------------------------

TICKERS_FILE = "companies_with_tickers.csv"   # Company, Sector, Ticker (NSE)
OUTPUT_DIR = "agent3_dataset"
MERGED_FILE = "agent3_dataset_master.csv"

os.makedirs(OUTPUT_DIR, exist_ok=True)

HEADERS = {
    "User-Agent":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)"
}

session = requests.Session()
session.headers.update(HEADERS)


# ----------------------------
# BUILD COMPANY URL FROM TICKER
# ----------------------------

def get_company_url(ticker):
    """
    Screener.in URLs are keyed on the NSE/BSE symbol directly, so there's no
    need to search — this avoids the fuzzy-match failures/wrong-company risk
    of the old search-based get_company_url(). Consolidated financials are
    preferred (bigger picture for group-level companies); if a company has no
    consolidated view (most standalone-only smaller caps), screener 404s and
    we fall back to the standalone page.
    """
    consolidated_url = f"https://www.screener.in/company/{ticker}/consolidated/"
    standalone_url = f"https://www.screener.in/company/{ticker}/"

    resp = session.get(consolidated_url, timeout=60)
    if resp.status_code == 200:
        return consolidated_url, resp.text

    resp = session.get(standalone_url, timeout=60)
    if resp.status_code == 200:
        return standalone_url, resp.text

    return None, None


# ----------------------------
# CLEAN TABLE
# ----------------------------

def convert(df):

    first = df.columns[0]

    df = df.rename(columns={first: "Metric"})
    df = df.set_index("Metric")

    df.index = (
        df.index
        .str.replace("+", "", regex=False)
        .str.strip()
    )

    return df.T


# ----------------------------
# FIND TABLE
# ----------------------------

def find_table(tables, keyword):

    for table in tables:

        first_col = table.iloc[:, 0].astype(str)

        if first_col.str.contains(keyword, case=False).any():
            return table

    return None


# ----------------------------
# SCRAPE
# ----------------------------

companies = pd.read_csv(TICKERS_FILE)

# de-dupe tickers up front (e.g. GSPL appearing twice under two company
# names) so we don't scrape and write the same company data twice
companies = companies.drop_duplicates(subset=["Ticker (NSE)"], keep="first")

for _, row in companies.iterrows():

    company = row["Company"]
    sector = row["Sector"]
    ticker = row["Ticker (NSE)"]

    print(f"\nScraping {company} ({ticker})")

    try:

        url, html = get_company_url(ticker)

        if url is None:
            print(f"Ticker {ticker} not found on screener.in")
            continue

        tables = pd.read_html(html)

        profit = find_table(tables, "Sales")
        balance = find_table(tables, "Equity Capital")
        cash = find_table(tables, "Cash from Operating")
        working = find_table(tables, "Debtor Days")

        if (
            profit is None or
            balance is None or
            cash is None or
            working is None
        ):
            print("Required table missing")
            continue

        profit = convert(profit)
        balance = convert(balance)
        cash = convert(cash)
        working = convert(working)

        years = [
            y for y in profit.index
            if "TTM" not in str(y)
        ]

        rows = []

        for year in years:

            record = {}

            record["Company"] = company
            record["Ticker"] = ticker
            record["Sector"] = sector
            record["Year"] = year

            # -----------------------
            # Profit Loss
            # -----------------------

            for c in profit.columns:
                record[c] = profit.loc[year].get(c)

            # -----------------------
            # Balance Sheet
            # -----------------------

            for c in balance.columns:
                record[c] = balance.loc[year].get(c)

            # -----------------------
            # Cash Flow
            # -----------------------

            for c in cash.columns:
                record[c] = cash.loc[year].get(c)

            # -----------------------
            # Working Capital
            # -----------------------

            for c in working.columns:
                record[c] = working.loc[year].get(c)

            rows.append(record)

        df = pd.DataFrame(rows)

        filename = ticker.replace("/", "-")   # ticker is filesystem-safe, unlike company name (e.g. "&", ".")

        df.to_csv(

            os.path.join(
                OUTPUT_DIR,
                f"{filename}.csv"
            ),

            index=False
        )

        print("Saved")

        time.sleep(2)

    except Exception as e:

        print(e)

        continue

print("\nDONE scraping")


# ----------------------------
# MERGE ALL PER-COMPANY CSVs
# ----------------------------

print("\nMerging all company CSVs...")

all_files = glob.glob(os.path.join(OUTPUT_DIR, "*.csv"))

if not all_files:
    print("No per-company CSVs found to merge.")
else:
    merged_df = pd.concat(
        [pd.read_csv(f) for f in all_files],
        ignore_index=True,
        sort=False,   # different companies can have slightly different columns
    )

    # Company/Ticker/Sector/Year first, then whatever financial columns follow
    lead_cols = [c for c in ["Company", "Ticker", "Sector", "Year"] if c in merged_df.columns]
    other_cols = [c for c in merged_df.columns if c not in lead_cols]
    merged_df = merged_df[lead_cols + other_cols]

    merged_df.to_csv(MERGED_FILE, index=False)
    print(f"Merged {len(all_files)} companies into {MERGED_FILE} ({len(merged_df)} rows total)")