import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from linearmodels.panel import PanelOLS
import statsmodels.api as sm
import warnings

warnings.filterwarnings("ignore")


# =====================================================
# PREPROCESS DATA
# =====================================================

def preprocess_data(file_path):

    print(f"Loading data from: {file_path}")

    df = pd.read_csv(file_path)

    # Convert "Mar 2020" -> 2020
    df["Year"] = (
        df["Year"]
        .astype(str)
        .str.extract(r"(\d{4})")
        .astype(int)
    )

    df = df.sort_values(
        ["Company", "Year"]
    ).reset_index(drop=True)

    # -----------------------------------------
    # Target variables
    # -----------------------------------------

    base_targets = [

        "Sales",
        "Operating Profit",
        "Net Profit",
        "Total Assets",
        "Borrowings",
        "CFO"

    ]

    # -----------------------------------------
    # Clean Inflation column
    # -----------------------------------------

    df["CPI_Inflation_Rate"] = (
        df["CPI_Inflation_Rate"]
        .astype(str)
        .str.replace("%", "", regex=False)
        .str.replace(",", "", regex=False)
    )

    df["CPI_Inflation_Rate"] = pd.to_numeric(
        df["CPI_Inflation_Rate"],
        errors="coerce"
    )

    # -----------------------------------------
    # Calculate YoY Growth
    # -----------------------------------------

    growth_columns = []

    for col in base_targets:

        new_col = f"{col}_Growth_Pct"

        growth_columns.append(new_col)

        previous = df.groupby("Company")[col].shift(1)

        denominator = previous.abs().replace(0, np.nan)

        df[new_col] = (
            (df[col] - previous)
            / denominator
        ) * 100

    # Remove first year

    df = df.dropna(subset=growth_columns)

    # -----------------------------------------
    # Remove Outliers
    # -----------------------------------------

    for col in growth_columns:

        lower = df[col].quantile(0.05)

        upper = df[col].quantile(0.95)

        df[col] = np.clip(
            df[col],
            lower,
            upper
        )

    # -----------------------------------------
    # Fill missing inflation values
    # -----------------------------------------

    df["CPI_Inflation_Rate"] = df[
        "CPI_Inflation_Rate"
    ].fillna(
        df["CPI_Inflation_Rate"].median()
    )

    # -----------------------------------------
    # Scale Inflation
    # -----------------------------------------

    scaler = StandardScaler()

    df[["CPI_Inflation_Rate"]] = scaler.fit_transform(
        df[["CPI_Inflation_Rate"]]
    )

    # -----------------------------------------
    # Panel Index
    # -----------------------------------------

    df = df.set_index(
        ["Company", "Year"]
    )

    return df


# =====================================================
# PANEL MODEL
# =====================================================

def run_panel(df, target):

    print("\n")
    print("=" * 60)
    print(target)
    print("=" * 60)

    y = df[target]

    X = df[["CPI_Inflation_Rate"]]

    X = sm.add_constant(X)

    model = PanelOLS(

        y,

        X,

        entity_effects=True,

        drop_absorbed=True

    )

    results = model.fit(

        cov_type="robust"

    )

    print(results.summary)

    print()

    print("Inflation Effect")

    print("-" * 40)

    impact = pd.DataFrame({

        "Coefficient":

            [results.params["CPI_Inflation_Rate"]],

        "P Value":

            [results.pvalues["CPI_Inflation_Rate"]],

        "Significant":

            [results.pvalues["CPI_Inflation_Rate"] < 0.05]

    })

    print(impact)

    return results


# =====================================================
# MAIN
# =====================================================

if __name__ == "__main__":

    DATA_FILE = "merged_filtered_data_cleaned.csv"

    panel_df = preprocess_data(DATA_FILE)

    targets = [

        "Sales_Growth_Pct",

        "Operating Profit_Growth_Pct",

        "Net Profit_Growth_Pct",

        "Total Assets_Growth_Pct",

        "Borrowings_Growth_Pct",

        "CFO_Growth_Pct"

    ]

    models = {}

    for target in targets:

        models[target] = run_panel(

            panel_df,

            target

        )

    print("\n")
    print("=" * 60)
    print("Training Complete")
    print("=" * 60)