import numpy as np

from app.schemas.common import AnalysisContext
from app.services.stress_engine import run_stress_test
from app.services.feature_engineering import build_risk_features, build_risk_breakdown
from app.models.lightgbm_model import LightGBMRiskModel
from app.models.shap_explainer import ShapExplainer
from app.utils.logger import get_logger

logger = get_logger(__name__)

# module-level singleton so the bootstrap-trained model isn't rebuilt per request
_risk_model = LightGBMRiskModel()
_explainer = ShapExplainer(_risk_model)


def run_stress_engine(context: AnalysisContext) -> AnalysisContext:
    """Deterministic simulation service (not an LLM agent) sitting between CFIA and SRIA."""
    logger.info("Running Stress Testing Engine")
    try:
        result = run_stress_test(
            company_dna=context.company_context.get("company_dna", {}),
            forecast=context.macro_context.get("inflation_forecast", {}),
            sector=context.metadata.sector,
        )
        context.stress_context = result
    except Exception as exc:
        logger.exception("Stress engine failed")
        context.errors.append(f"stress_engine: {exc}")
    return context


def run_risk_agent(context: AnalysisContext) -> AnalysisContext:
    """Agent 3 (SRIA): predicts financial distress probability via LightGBM + SHAP."""
    logger.info("Running Scenario & Risk Intelligence Agent")
    try:
        stress_test = context.stress_context.get("stress_test", {})
        ratios = context.company_context.get("financial_ratios", {})
        dna = context.company_context.get("company_dna", {})
        forecast = context.macro_context.get("inflation_forecast", {})

        X = build_risk_features(stress_test, dna, ratios, forecast)
        probability = float(_risk_model.predict_proba(X)[0])
        risk_score = round(probability * 100, 1)
        category = "Low" if probability < 0.3 else "Medium" if probability < 0.6 else "High"

        avg_inflation = (
            sum(p["inflation"] for p in forecast.get("forecast", [])) / len(forecast.get("forecast", []))
            if forecast.get("forecast") else 5.0
        )
        breakdown = build_risk_breakdown(ratios, dna, stress_test, avg_inflation)
        feature_importance = _explainer.explain(X)

        context.risk_context = {
            "risk_assessment": {
                "financial_distress_probability": round(probability, 2),
                "risk_category": category,
                "risk_score": risk_score,
            },
            "risk_breakdown": breakdown,
            "feature_importance": feature_importance,
        }
    except Exception as exc:
        logger.exception("Risk agent failed")
        context.errors.append(f"risk_agent: {exc}")
    return context
