from app.schemas.common import AnalysisContext
from app.utils.llm_client import complete_json
from app.utils.logger import get_logger

logger = get_logger(__name__)

_SYSTEM_PROMPT = (
    "You are a strategic financial advisor generating recommendations for a "
    "company management team. You are given the inflation forecast, financial "
    "health, stress test results, risk assessment, and Company DNA. Do not "
    "invent numbers not present in the input. Respond in strict JSON with keys: "
    "pricing, inventory, financing, cost_control, cash_management (all short "
    "strings), executive_summary (2-3 sentences), priority_actions (list of 3 short strings)."
)

_FALLBACK = {
    "pricing": "Increase prices gradually in line with cost inflation while monitoring demand elasticity.",
    "inventory": "Reduce excess inventory exposure to volatile input costs.",
    "financing": "Refinance variable-rate debt to lock in costs ahead of further rate moves.",
    "cost_control": "Optimize procurement and renegotiate supplier contracts.",
    "cash_management": "Build liquidity reserves to absorb margin compression.",
    "executive_summary": "The company faces moderate margin pressure from the forecasted inflation "
                          "regime but retains a manageable risk profile; proactive pricing and cost "
                          "actions can preserve profitability.",
    "priority_actions": [
        "Review pricing strategy against updated cost inflation assumptions",
        "Stress-test working capital under the projected scenario",
        "Reassess debt structure for refinancing opportunities",
    ],
}


def run_strategy_agent(context: AnalysisContext) -> AnalysisContext:
    """Agent 4 (SDIA): synthesizes every prior agent's output into recommendations."""
    logger.info("Running Strategic Decision Intelligence Agent")
    try:
        prompt = (
            f"Inflation forecast: {context.macro_context.get('inflation_forecast', {})}. "
            f"Inflation regime: {context.macro_context.get('inflation_regime', {})}. "
            f"Financial health: {context.company_context.get('financial_health', {})}. "
            f"Company DNA: {context.company_context.get('company_dna', {})}. "
            f"Stress test: {context.stress_context.get('stress_test', {})}. "
            f"Risk assessment: {context.risk_context.get('risk_assessment', {})}. "
            "Generate the strategy JSON."
        )
        result = complete_json(prompt, system=_SYSTEM_PROMPT)
        if "raw_response" in result or not result.get("priority_actions"):
            result = _FALLBACK

        context.strategy_context = {
            "strategy": {
                "pricing": result.get("pricing", _FALLBACK["pricing"]),
                "inventory": result.get("inventory", _FALLBACK["inventory"]),
                "financing": result.get("financing", _FALLBACK["financing"]),
                "cost_control": result.get("cost_control", _FALLBACK["cost_control"]),
                "cash_management": result.get("cash_management", _FALLBACK["cash_management"]),
            },
            "executive_summary": result.get("executive_summary", _FALLBACK["executive_summary"]),
            "priority_actions": result.get("priority_actions", _FALLBACK["priority_actions"]),
        }
    except Exception as exc:
        logger.exception("Strategy agent failed")
        context.errors.append(f"strategy_agent: {exc}")
        context.strategy_context = {
            "strategy": {k: v for k, v in _FALLBACK.items() if k not in ("executive_summary", "priority_actions")},
            "executive_summary": _FALLBACK["executive_summary"],
            "priority_actions": _FALLBACK["priority_actions"],
        }
    return context
