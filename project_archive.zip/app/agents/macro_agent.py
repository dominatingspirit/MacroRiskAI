import os
import numpy as np
import pandas as pd
import joblib

# Import the new live data service
from app.services.macro_api_service import MacroApiService

class MacroAgent:
    def __init__(self):
        self.models_dir = "app/models"
        self.xgb_model = self._load_model("xgboost_inflation_model.pkl")
        self.lgb_model = self._load_model("lightgbm_inflation_model.pkl")
        self.arimax_model = self._load_model("arimax_inflation_model.pkl")
        self.var_model = self._load_model("var_macro_model.pkl")

        self.weights = {
            'XGBoost': 0.29,   
            'LightGBM': 0.28,  
            'ARIMAX': 0.21,    
            'VAR': 0.22        
        }

    def _load_model(self, filename):
        path = os.path.join(self.models_dir, filename)
        if os.path.exists(path):
            return joblib.load(path)
        print(f"Warning: Model {filename} not found in {self.models_dir}")
        return None

    def execute(self, input_payload: dict = None) -> dict:
        # --- THE REAL-TIME DATA UPGRADE ---
        # If no test payload is provided, fetch the live data automatically!
        if not input_payload or "macroeconomic_data" not in input_payload:
            input_payload = MacroApiService.fetch_current_payload()
            
        macro_data = input_payload.get("macroeconomic_data", [])
        latest = macro_data[-1]
        
        # (The rest of your exact code remains untouched below this point)
        target_month = latest.get('date')
        current_month = pd.to_datetime(target_month).month

        cpi_lag_1 = latest.get('cpi_lag_1', 4.0)
        cpi_lag_2 = latest.get('cpi_lag_2', 4.0)
        wpi_lag_1 = latest.get('wpi_lag_1', 3.0)
        oil_lag_1 = latest.get('oil_lag_1', 75.0)

        raw_wpi = latest.get('wpi', 0.0)
        raw_repo = latest.get('repo_rate', 6.5)
        raw_oil = latest.get('oil_price', 75.0)
        raw_exchange = latest.get('exchange_rate', 83.0)

        # Feature vector for forecasting models
        features = pd.DataFrame([{
            'WPI': raw_wpi,
            'Repo_Rate': raw_repo,
            'oil_price': raw_oil,
            'exchange_rate': raw_exchange,
            'Month': current_month,
            'CPI_lag_1': cpi_lag_1,
            'CPI_lag_2': cpi_lag_2,
            'WPI_lag_1': wpi_lag_1,
            'Oil_lag_1': oil_lag_1
        }])

        indiv_preds = {}
        weighted_predictions = []
        weights_used = []

        if self.xgb_model:
            xgb_val = cpi_lag_1 + self.xgb_model.predict(features)[0]
            indiv_preds['XGBoost'] = round(float(xgb_val), 2)
            weighted_predictions.append(xgb_val * self.weights['XGBoost'])
            weights_used.append(self.weights['XGBoost'])

        if self.lgb_model:
            lgb_val = cpi_lag_1 + self.lgb_model.predict(features)[0]
            indiv_preds['LightGBM'] = round(float(lgb_val), 2)
            weighted_predictions.append(lgb_val * self.weights['LightGBM'])
            weights_used.append(self.weights['LightGBM'])

        if self.arimax_model:
            try:
                exog_row = features[['WPI', 'Repo_Rate', 'oil_price', 'exchange_rate']]
                ari_val = self.arimax_model.forecast(steps=1, exog=exog_row).iloc[0]
                indiv_preds['ARIMAX'] = round(float(ari_val), 2)
                weighted_predictions.append(ari_val * self.weights['ARIMAX'])
                weights_used.append(self.weights['ARIMAX'])
            except: pass

        if self.var_model:
            try:
                var_input = np.array([[cpi_lag_1, wpi_lag_1, oil_lag_1, raw_exchange]])
                var_val = self.var_model.forecast(var_input, steps=1)[0][0]
                indiv_preds['VAR'] = round(float(var_val), 2)
                weighted_predictions.append(var_val * self.weights['VAR'])
                weights_used.append(self.weights['VAR'])
            except: pass

        ensemble_forecast_value = round(float(sum(weighted_predictions) / sum(weights_used)), 2) if sum(weights_used) > 0 else cpi_lag_1
        lower_ci = round(ensemble_forecast_value - 0.47, 2)
        upper_ci = round(ensemble_forecast_value + 0.47, 2)

        if len(indiv_preds) > 1:
            std_dev = np.std(list(indiv_preds.values()))
            derived_conf = round(float(max(0.40, 0.96 - (std_dev * 0.15))), 2)
        else:
            derived_conf = 0.50
        conf_label = "High" if derived_conf >= 0.85 else "Medium" if derived_conf >= 0.70 else "Low"

        # --- DYNAMIC FORMULA WITH ZERO-BOUND PROTECTION ---
        base_dp = max(0.0, (
            40.0
            - 2.0 * raw_wpi
            - 1.5 * max(0, raw_oil - 70)
            + 1.0 * (85.0 - raw_exchange)
        ))

        base_cp = max(0.0, (
            10.0
            + 3.5 * raw_wpi
            + 0.8 * max(0, raw_oil - 70)
            + 1.2 * max(0, raw_exchange - 82.0)
        ))

        base_cd = max(0.0, (
            10.0
            + max(0, (4.5 - ensemble_forecast_value) * 15)
            + 1.5 * max(0, 6.0 - raw_repo)
        ))

        base_stag = max(0.0, (
            5.0
            + (max(0, raw_wpi - 5.0) * 3)
            + max(0, (ensemble_forecast_value - 5.0) * 5)
            + 0.5 * max(0, raw_oil - 80)
        ))

        total_weight = base_dp + base_cp + base_cd + base_stag
        if total_weight == 0: total_weight = 1 

        prob_dp = int(round((base_dp / total_weight) * 100))
        prob_cp = int(round((base_cp / total_weight) * 100))
        prob_cd = int(round((base_cd / total_weight) * 100))
        prob_stag = max(0, 100 - (prob_dp + prob_cp + prob_cd)) 

        prob_dist = {
            "Demand Pull": prob_dp,
            "Cost Push": prob_cp,
            "Cooling/Deflation": prob_cd,
            "Stagflation": prob_stag
        }

        primary_regime = max(prob_dist, key=prob_dist.get)
        commodity_pressure = "High" if (raw_wpi > 7.0 or raw_oil > 85.0) else "Moderate"

        return {
            "inflation_forecast": {
                "forecast": [
                    {
                        "month": target_month,
                        "inflation": ensemble_forecast_value,
                        "lower_ci": lower_ci,
                        "upper_ci": upper_ci
                    }
                ],
                "model_used": "Delta-Stacked Ensemble (XGB+LGB+ARIMAX+VAR)",
                "confidence_score": derived_conf,
                "model_agreement": conf_label
            },
            "ensemble_breakdown": indiv_preds,
            "inflation_regime": {
                "class": primary_regime,
                "probabilistic_distribution": prob_dist
            },
            "macro_summary": {
                "inflation_trend": "Decreasing" if ensemble_forecast_value < cpi_lag_1 else "Increasing",
                "policy_outlook": "Neutral" if raw_repo >= 6.5 else "Accommodative",
                "commodity_pressure": commodity_pressure
            }
        }

if __name__ == "__main__":
    import json
    # Running without passing test_input will automatically trigger the live data fetch!
    agent = MacroAgent()
    result = agent.execute()
    print("Agent Execution Successful! Real-Time JSON Output:\n")
    print(json.dumps(result, indent=4))