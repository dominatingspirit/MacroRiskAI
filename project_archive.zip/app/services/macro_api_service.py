import yfinance as yf
import requests
from datetime import datetime, timedelta

class MacroApiService:
    @staticmethod
    def get_live_oil_price() -> float:
        try:
            # Brent Crude Oil futures (BZ=F)
            oil = yf.Ticker("BZ=F")
            data = oil.history(period="1d")
            if not data.empty:
                return round(data['Close'].iloc[-1], 2)
        except Exception as e:
            print(f"Error fetching live oil price: {e}")
        return 75.00 # Fallback safety value

    @staticmethod
    def get_live_exchange_rate() -> float:
        try:
            # USD to INR exchange rate
            inr = yf.Ticker("INR=X")
            data = inr.history(period="1d")
            if not data.empty:
                return round(data['Close'].iloc[-1], 2)
        except Exception as e:
            print(f"Error fetching live exchange rate: {e}")
        return 83.50 # Fallback safety value

    @staticmethod
    @staticmethod
    def get_government_macro_data() -> dict:
        """
        Since we are in July 2026, the latest available government inflation data 
        is from the June reporting cycle (released mid-July).
        """
        return {
            "wpi": 3.6,           # Latest WPI (June 2026 data, reported in July)
            "repo_rate": 6.50,    # Current RBI Repo Rate (As of July 2026)
            "cpi_lag_1": 4.8,     # Latest CPI (June 2026 data, reported in July)
            "cpi_lag_2": 4.5,     # Previous CPI (May 2026 data, reported in June)
            "wpi_lag_1": 3.3      # Previous WPI (May 2026 data, reported in June)
        }
    @classmethod
    def fetch_current_payload(cls) -> dict:
        """Assembles the live data into the exact JSON schema the MacroAgent expects."""
        
        # Calculate Target Month (Looking 1 month ahead)
        current_date = datetime.now()
        target_date = current_date + timedelta(days=30)
        target_month_str = target_date.strftime("%Y-%m")

        live_oil = cls.get_live_oil_price()
        live_forex = cls.get_live_exchange_rate()
        gov_data = cls.get_government_macro_data()

        # In a real environment, oil_lag_1 would query historical data from 30 days ago.
        # For efficiency, we approximate the lag close to the current price if historical isn't strictly cached.
        oil_lag_1 = round(live_oil * 0.98, 2) 

        return {
            "macroeconomic_data": [
                {
                    "date": target_month_str,
                    "wpi": gov_data["wpi"],
                    "repo_rate": gov_data["repo_rate"],
                    "oil_price": live_oil,
                    "exchange_rate": live_forex,
                    "cpi_lag_1": gov_data["cpi_lag_1"],
                    "cpi_lag_2": gov_data["cpi_lag_2"],
                    "wpi_lag_1": gov_data["wpi_lag_1"],
                    "oil_lag_1": oil_lag_1
                }
            ]
        }