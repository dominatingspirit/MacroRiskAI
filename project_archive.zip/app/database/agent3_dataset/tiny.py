import requests

try:
    r = requests.get(
        "https://www.screener.in/company/HINDUNILVR/",
        timeout=20,
        headers={
            "User-Agent": "Mozilla/5.0"
        }
    )

    print(r.status_code)

except Exception as e:
    print(e)