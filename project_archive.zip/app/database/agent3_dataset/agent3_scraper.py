import os
import time
import glob
from io import StringIO

import requests
import pandas as pd
import random

# =====================================================
# CONFIG
# =====================================================

TICKERS_FILE = "companies_with_tickers.csv"

OUTPUT_DIR = "agent3_dataset"

MERGED_FILE = "agent3_dataset_master.csv"

os.makedirs(OUTPUT_DIR, exist_ok=True)

HEADERS = {

    "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

}

session = requests.Session()

session.headers.update(HEADERS)


# =====================================================
# TABLE CONVERTER (UNCHANGED)
# =====================================================

def table_to_dict(df):

    """
    Converts Screener table into

    {
      "Sales": {
          "Mar 2015": value,
          ...
      }
    }
    """

    first = df.columns[0]

    data = {}

    for _, row in df.iterrows():

        metric = str(row[first])

        metric = (

            metric.replace("+", "")
                  .replace("%", "")
                  .strip()

        )

        values = {}

        for col in df.columns[1:]:

            values[col] = row[col]

        data[metric] = values

    return data


# =====================================================
# LOAD CSV
# =====================================================

companies = pd.read_csv(TICKERS_FILE)

companies = companies.drop_duplicates(
    subset=["Ticker (NSE)"],
    keep="first"
)

# =====================================================
# RESUME SUPPORT
# =====================================================

done = {

    os.path.basename(f).replace(".csv", "")

    for f in glob.glob(

        os.path.join(
            OUTPUT_DIR,
            "*.csv"
        )

    )

}

print()

print(f"{len(done)} companies already scraped.")

print()


# =====================================================
# LOOP
# =====================================================

for index, row in companies.iterrows():

    company = row["Company"]

    sector = row["Sector"]

    ticker = row["Ticker (NSE)"]

    if ticker in done:

        print(f"Skipping {ticker}")

        continue

    print()

    print("=" * 60)

    print(f"[{index+1}/{len(companies)}]")

    print(company)

    print(ticker)

    print("=" * 60)

    html = None

    urls = [

        f"https://www.screener.in/company/{ticker}/consolidated/",

        f"https://www.screener.in/company/{ticker}/"

    ]

    for url in urls:

        try:

            response = session.get(

                url,

                timeout=30

            )

            if response.status_code == 200:

                html = response.text

                print("Fetched:", url)

                break

        except Exception:

            pass

    if html is None:

        print("Couldn't fetch company.")

        continue

    try:

        tables = pd.read_html(

            StringIO(html)

        )

        # SAME TABLES AS YOUR WORKING SCRIPT
        print("Total tables:", len(tables))
        profit = tables[1]

        balance = tables[6]

        cash = tables[7]

        ratios = tables[8]

        profit_dict = table_to_dict(profit)

        balance_dict = table_to_dict(balance)

        cash_dict = table_to_dict(cash)

        ratio_dict = table_to_dict(ratios)
        
                # =====================================================
        # KEEP ONLY 2015-2025
        # =====================================================

        years = []

        for col in profit.columns[1:]:

            year = str(col)

            if "TTM" in year:
                continue

            try:

                year_number = int(year.split()[-1])

            except Exception:

                continue

            if 2015 <= year_number <= 2025:

                years.append(col)

        rows = []

        # =====================================================
        # BUILD ROWS
        # =====================================================

        for year in years:

            try:

                record = {

                    "Company": company,

                    "Ticker": ticker,

                    "Sector": sector,

                    "Year": year,

                    # -----------------------
                    # PROFIT & LOSS
                    # -----------------------

                    "Sales":
                        profit_dict["Sales"][year],

                    "Expenses":
                        profit_dict["Expenses"][year],

                    "Operating Profit":
                        profit_dict["Operating Profit"][year],

                    "OPM":
                        profit_dict["OPM"][year],

                    "Other Income":
                        profit_dict["Other Income"][year],

                    "Interest":
                        profit_dict["Interest"][year],

                    "Depreciation":
                        profit_dict["Depreciation"][year],

                    "Profit Before Tax":
                        profit_dict["Profit before tax"][year],

                    "Tax":
                        profit_dict["Tax"][year],

                    "Net Profit":
                        profit_dict["Net Profit"][year],

                    "EPS":
                        profit_dict["EPS in Rs"][year],

                    # -----------------------
                    # BALANCE SHEET
                    # -----------------------

                    "Equity":
                        balance_dict["Equity Capital"][year],

                    "Reserves":
                        balance_dict["Reserves"][year],

                    "Borrowings":
                        balance_dict["Borrowings"][year],

                    "Other Liabilities":
                        balance_dict["Other Liabilities"][year],

                    "Total Liabilities":
                        balance_dict["Total Liabilities"][year],

                    "Fixed Assets":
                        balance_dict["Fixed Assets"][year],

                    "CWIP":
                        balance_dict["CWIP"][year],

                    "Investments":
                        balance_dict["Investments"][year],

                    "Other Assets":
                        balance_dict["Other Assets"][year],

                    "Total Assets":
                        balance_dict["Total Assets"][year],

                    # -----------------------
                    # CASH FLOW
                    # -----------------------

                    "CFO":
                        cash_dict["Cash from Operating Activity"][year],

                    "CFI":
                        cash_dict["Cash from Investing Activity"][year],

                    "CFF":
                        cash_dict["Cash from Financing Activity"][year],

                    "Net Cash Flow":
                        cash_dict["Net Cash Flow"][year],

                    "Free Cash Flow":
                        cash_dict["Free Cash Flow"][year],

                    # -----------------------
                    # RATIOS
                    # -----------------------

                    "Debtor Days":
                        ratio_dict["Debtor Days"][year],

                    "Inventory Days":
                        ratio_dict["Inventory Days"][year],

                    "Days Payable":
                        ratio_dict["Days Payable"][year],

                    "Cash Conversion Cycle":
                        ratio_dict["Cash Conversion Cycle"][year],

                    "Working Capital Days":
                        ratio_dict["Working Capital Days"][year]

                }

                rows.append(record)

            except KeyError as e:

                print(
                    f"Missing metric/year for {ticker} ({year}): {e}"
                )

                continue
            
                    # =====================================================
        # SAVE COMPANY CSV
        # =====================================================

        if len(rows) == 0:

            print("No usable rows found.")

            continue

        final = pd.DataFrame(rows)

        filename = ticker.replace("/", "-")

        output_file = os.path.join(
            OUTPUT_DIR,
            f"{filename}.csv"
        )

        final.to_csv(
            output_file,
            index=False
        )

        print(f"Saved -> {output_file}")

        # Be nice to Screener
        time.sleep(random.uniform(2,4))

    except Exception as e:
        print(f"Error while processing {ticker}")

        print(e)

        continue


print()

print("=" * 60)

print("Finished scraping all companies.")

print("=" * 60)

print()

# =====================================================
# MERGE ALL COMPANY CSVs
# =====================================================

print()

print("Merging all company CSVs...")

all_files = glob.glob(

    os.path.join(
        OUTPUT_DIR,
        "*.csv"
    )

)

if len(all_files) == 0:

    print("No company CSVs found.")

else:

    merged = pd.concat(

        [

            pd.read_csv(f)

            for f in all_files

        ],

        ignore_index=True,

        sort=False

    )

    # Put identifier columns first

    lead_columns = [

        c

        for c in [

            "Company",

            "Ticker",

            "Sector",

            "Year"

        ]

        if c in merged.columns

    ]

    other_columns = [

        c

        for c in merged.columns

        if c not in lead_columns

    ]

    merged = merged[lead_columns + other_columns]

    merged.to_csv(

        MERGED_FILE,

        index=False

    )

    print()

    print("=" * 60)

    print(f"Merged {len(all_files)} companies.")

    print(f"Rows : {len(merged)}")

    print(f"Saved: {MERGED_FILE}")

    print("=" * 60)