import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, DateTime, JSON
from app.database.db import Base


class AnalysisRun(Base):
    __tablename__ = "analysis_runs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    company_name = Column(String, index=True)
    sector = Column(String)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    result = Column(JSON)
